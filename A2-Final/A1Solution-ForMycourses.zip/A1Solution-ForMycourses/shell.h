
int parseInput(char ui[]);